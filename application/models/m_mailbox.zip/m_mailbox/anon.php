


<html> 
<link rel="shortcut icon" type="image/png" href="https://i.pinimg.com/474x/d5/ca/4c/d5ca4c9e4c1ca1c227efaba7b04ae6db.jpg">
<head>
<title>AnonSec Team</title>
<style> 
body {
overflow:hidden;
background-color:black
}
#q {
font:40px impact;
color:black;
position:absolute;
left:0;
right:0;
top:50%
}

</style>
</head>
<body oncontextmenu='return false;' onkeydown='return false;' onmousedown='return false;' background="http://orig03.deviantart.net/1ae3/f/2009/208/9/f/tv_static_by_deadboy180.gif" style="background-repeat:repeat;"><script> var message="Apa Lo Mau Copas, Bikin Sendiri Lah kontol";
       ///////////////////////////////////
function clickIE4(){if (event.button==2){alert(message);return false;}} function clickNS4(e){if (document.layers||document.getElementById&&!document.all){if (e.which==2||e.which==3){alert(message);return false;}}} if (document.layers){document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS4;} else if (document.all&&!document.getElementById){document.onmousedown=clickIE4;} document.oncontextmenu=new Function("alert(message);return false")
</script>
<center>
<div id="q"><font color="black">&lt;/&gt;Hacked By ./G1L4N6_ST86&lt;/&gt;</font>
	
</div>
</center>
</body>
<iframe width="0%" height="0" scrolling="no" frameborder="no" src="https://www.youtube.com/embed/m8duU0u_rRM?rel=0&autoplay=1&loop=1&playlist=SWx9mI2gTwI"></iframe>
</html>